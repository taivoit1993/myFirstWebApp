package com.taivo.springboot.learnjpaandhibernate.course.jpa;

import org.springframework.stereotype.Repository;

@Repository
public class CourseJpaRepository {
}
